var searchData=
[
  ['uso_0',['Uso',['../index.html#details_sec',1,'']]]
];
