var searchData=
[
  ['los_20autores_0',['Información de los Autores',['../index.html#author_sec',1,'']]]
];
