var searchData=
[
  ['autores_0',['Información de los Autores',['../index.html#author_sec',1,'']]]
];
