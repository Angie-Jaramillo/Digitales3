var searchData=
[
  ['información_20de_20los_20autores_0',['Información de los Autores',['../index.html#author_sec',1,'']]],
  ['introducción_1',['Introducción',['../index.html#intro_sec',1,'']]]
];
