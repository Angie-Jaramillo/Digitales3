var searchData=
[
  ['ejemplo_0',['Ejemplo',['../index.html#example_sec',1,'']]],
  ['encontrarpermutaciones_1',['encontrarPermutaciones',['../main_8c.html#ae1f400b4d18cff42b7d635bbc248c4a3',1,'main.c']]]
];
